<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
            <?php echo e(__('Penjualan')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="gap-5 items-start flex">
                <div class="bg-white dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg w-full p-4">
                    <div class="p-4 bg-gray-100 mb-2 rounded-xl font-bold">
                        <div class="flex items-center justify-between">
                            <div class="w-full">
                                PENJUALAN
                            </div>
                            
                            <div>
                                <a href="<?php echo e(route('penjualan.create')); ?>"
                                    class="bg-sky-400 p-1 text-white rounded-xl px-4">Tambah</a>
                            </div>
                        </div>
                    </div>
                    <div>
                        <div class="relative overflow-x-auto">
                            <table class="w-full text-sm text-left rtl:text-right text-gray-500 dark:text-gray-400">
                                <thead
                                    class="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
                                    <tr>
                                        <th scope="col" class="px-6 py-3 bg-gray-100">
                                            NO
                                        </th>
                                        <th scope="col" class="px-6 py-3">
                                            KODE PENJUALAN
                                        </th>
                                        <th scope="col" class="px-6 py-3">
                                            TGL PENJUALAN
                                        </th>
                                        <th scope="col" class="px-6 py-3">
                                            KONSUMEN
                                        </th>
                                        <th scope="col" class="px-6 py-3">
                                            STATUS PEMBELIAN
                                        </th>
                                        <th scope="col" class="px-6 py-3">
                                            TOTAL HARGA
                                        </th>
                                        <th scope="col" class="px-6 py-3">
                                            TOTAL BAYAR
                                        </th>
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('role-A')): ?>
                                            <th scope="col" class="px-6 py-3">
                                                ACTION
                                            </th>
                                        <?php endif; ?>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                        $no = 1;
                                    ?>
                                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr class="bg-white border-b dark:bg-gray-800 dark:border-gray-700">
                                            <th scope="row"
                                                class="px-6 py-4 font-medium text-gray-900 whitespace-nowrap dark:text-white bg-gray-100">
                                                <?php echo e($no++); ?>

                                            </th>
                                            <td class="px-6 py-4">
                                                <?php echo e($f->kode_penjualan); ?>

                                            </td>
                                            <td class="px-6 py-4 bg-gray-100">
                                                <?php echo e($f->tgl_penjualan); ?>

                                            </td>
                                            <td class="px-6 py-4 bg-gray-100">
                                                <?php echo e($f->konsumen->nama_konsumen); ?>

                                            </td>
                                            <td class="px-6 py-4 bg-gray-100">
                                                <?php echo e($f->status_pembelian); ?>

                                            </td>
                                            <td class="px-6 py-4 bg-gray-100">
                                                <?php echo e($f->total_jual); ?>

                                            </td>
                                            <td class="px-6 py-4 bg-gray-100">
                                                <?php echo e($f->total_bayar); ?>

                                            </td>
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('role-A')): ?>
                                                <td class="px-6 py-4 bg-gray-100">
                                                    <button
                                                        class="bg-red-400 p-3 w-10 h-10 rounded-xl text-white hover:bg-red-500"
                                                        onclick="return dataDelete('<?php echo e($f->id); ?>','<?php echo e($f->konsumen->nama_konsumen); ?>')">
                                                        <i class="fi fi-sr-delete-document"></i>
                                                    </button>
                                                </td>
                                            <?php endif; ?>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                        <div class="mt-4">
                            <?php echo e($data->links()); ?>

                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
    <script>
        const dataDelete = async (id, nama_konsumen) => {
            let tanya = confirm(`Apakah anda yakin untuk menghapus transaksi ${nama_konsumen}?`);
            if (tanya) {
                try {
                    const response = await axios.post(`/penjualan/${id}`, {
                        '_method': 'DELETE',
                        '_token': document.querySelector('meta[name="csrf-token"]').getAttribute('content')
                    });

                    if (response.status === 200) {
                        alert('Transaksi berhasil dihapus');
                        location.reload();
                    } else {
                        alert('Gagal menghapus transaksi. Silakan coba lagi.');
                    }
                } catch (error) {
                    console.error(error);
                    alert('Terjadi kesalahan saat menghapus transaksi. Silakan cek konsol untuk detail.');
                }
            }
        };
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH D:\Kuliah\GITHUB\Project-Laravel\tugas kasir\Kasir-LP3I-2\resources\views/page/penjualan/index.blade.php ENDPATH**/ ?>