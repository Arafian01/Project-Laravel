<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
            <?php echo e(__('Penjualan')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="gap-5 items-start flex">
                <div class="bg-white dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg w-full p-4">
                    <div class="p-4 bg-gray-100 mb-6 rounded-xl font-bold">
                        <div class="flex items-center justify-between">
                            <div class="w-full">
                                FORM INPUT PENJUALAN
                            </div>
                        </div>
                    </div>
                    
                    <div>
                        <form class="w-full mx-auto" method="POST" action="<?php echo e(route('penjualan.store')); ?>">
                            <?php echo csrf_field(); ?>
                            <div class="flex gap-5">
                                <div class="mb-5 w-full">
                                    <label for="kode_penjualan"
                                        class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Kode
                                        Penjualan</label>
                                    <input type="text" id="kode_penjualan" name="kode_penjualan"
                                        value="<?php echo e($kodePenjualan); ?>"
                                        class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                                        placeholder="Kode Penjualan" readonly required />
                                </div>
                                <div class="mb-5 w-full">
                                    <label for="tgl_penjualan"
                                        class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Tanggal
                                        Penjualan</label>
                                    <input type="date" id="tgl_penjualan" name="tgl_penjualan"
                                        value="<?php echo e(date('Y-m-d')); ?>"
                                        class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                                        required />
                                </div>
                            </div>
                            <div class="flex gap-5">
                                
                                
                                
                            </div>
                            
                            <div class="p-4 bg-gray-100 mb-6 rounded-xl font-bold">
                                <div class="flex items-center justify-between">
                                    <div class="w-full">
                                        DETAIL PRODUK PENJUALAN
                                    </div>
                                    <div><button id="addRowBtn"
                                            class="bg-sky-400 hover:bg-sky-500 text-white px-2 rounded-xl">+</button>
                                    </div>
                                </div>
                            </div>
                            <div class="mb-4">
                                <div class="border border-2 rounded-xl p-2 mb-2" id="produkContainer">
                                </div>
                            </div>
                            
                            <div class="gap-5 flex">
                                <div class="mb-5 w-full">
                                    <label for="total_jual"
                                        class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Total</label>
                                    <input type="number" id="total_jual" name="total_jual"
                                        class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                                        required />
                                </div>
                                <div class="mb-5 w-full">
                                    <label for="konsumen"
                                        class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Konsumen</label>
                                    <select class="js-example-placeholder-single js-states form-control w-full m-6"
                                        id="id_konsumen" name="id_konsumen" data-placeholder="Pilih Konsumen"
                                        onchange="updateStatusPembelian()">
                                        <option value="">Pilih...</option>
                                        <?php $__currentLoopData = $konsumen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($k->id); ?>" data-status="<?php echo e($k->status); ?>">
                                                <?php echo e($k->nama_konsumen); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="mb-5 w-full">
                                    <label for="total_bayar"
                                        class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Total
                                        Bayar</label>
                                    <input type="number" id="total_bayar" name="total_bayar"
                                        class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                                        required />
                                </div>
                                <div class="mb-5 w-full">
                                    <label for="piutangKembali"
                                        class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Piutang/Kembali</label>
                                    <input type="number" id="piutangKembali" name="piutangKembali"
                                        class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                                        required readonly/>
                                </div>
                            </div>
                            <button type="submit"
                                class="text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm w-full sm:w-auto px-5 py-2.5 text-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800">Submit</button>
                        </form>
                    </div>
                    
                </div>
            </div>
        </div>
    </div>
    <script>
        $(document).ready(function() {
            // Fungsi menghitung Piutang/kembali
            function calculatePiutangKembali() {
                const totalJual = parseFloat($('#total_jual').val()) || 0;
                const totalBayar = parseFloat($('#total_bayar').val()) || 0;
                const piutangKembali = totalBayar - totalJual;
                $('#piutangKembali').val(piutangKembali);
            }

            // Event listener untuk total_bayar
            $('#total_bayar').on('input', function() {
                calculatePiutangKembali();
            });

            // MENAMBAH ROW DETAIL PRODUK PENJUALAN
            $('#addRowBtn').click(function(event) {
                event.preventDefault();
                addRow();
            });

            let rowCount = 0;

            function addRow() {
                rowCount++;
                const newRow = `<div class="border border-2 rounded-xl mb-2 p-2" id="row${rowCount}">
                                <div class="flex mb-2 gap-2">
                                    <div class="mb-5 w-full">
                                        <label for="produk${rowCount}"
                                            class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Produk</label>
                                        <select id="produk${rowCount}" name="produk[]" class="form-control w-full"
                                            onchange="getProduk(${rowCount})">
                                            <option value="">Pilih...</option>
                                            <?php $__currentLoopData = $produk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($k->kode_produk); ?>"><?php echo e($k->produk); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>

                                    <div class="mb-5 w-full">
                                        <label for="harga${rowCount}"
                                            class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Harga</label>
                                        <input type="number" id="harga${rowCount}" name="harga[]" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" readonly />
                                    </div>
                                    <div class="mb-5 w-full">
                                        <label for="qty${rowCount}"
                                            class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Qty</label>
                                        <input type="number" id="qty${rowCount}" name="qty[]"
                                            class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                                            required value="0"/>
                                    </div>
                                    <div class="mb-5 w-full">
                                        <label for="total_harga${rowCount}"
                                            class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Total Harga</label>
                                        <input type="number" id="total_harga${rowCount}" name="total_harga[]"
                                            class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                                            required readonly/>
                                    </div>
                                    <button type="button" class="px-2 bg-red-100" onclick="removeRow(${rowCount})">
                                        Hapus
                                    </button>
                                </div>
                            </div>`;
                $('#produkContainer').append(newRow);
                $(`#produk${rowCount}`).select2({
                    placeholder: "Pilih Produk"
                });

                // tambahin ini
                bindRowEvents(rowCount);
            }

            function bindRowEvents(rowId) {
                const hargaInput = document.getElementById(`harga${rowId}`);
                const qtyInput = document.getElementById(`qty${rowId}`);
                const totalHargaInput = document.getElementById(`total_harga${rowId}`);

                // Perhitungan total harga
                const calculateTotalHarga = () => {
                    const harga = parseFloat(hargaInput.value) || 0;
                    const qty = parseInt(qtyInput.value) || 0;
                    totalHargaInput.value = harga * qty;

                    //MENGHITUNG TOTAL JUAL
                    calculateTotalJual();
                };
                qtyInput.addEventListener("input", calculateTotalHarga);
            }

            //PERHITUNGAN TOTAL JUAL
            function calculateTotalJual() {
                let totalJual = 0;
                $("[id^='total_harga']").each(function() {
                    totalJual += parseFloat($(this).val()) || 0;
                });
                $('#total_jual').val(totalJual);
            }
        });

        // MENGHAPUS ROW DETAIL PRODUK PENJUALAN
        function removeRow(rowId) {
            $(`#row${rowId}`).remove();
            updateRowNumbers();
        }
    </script>

    <script>
        const getProduk = (rowCount) => {
            const produkId = document.getElementById(`produk${rowCount}`).value;

            if (!produkId) {
                document.getElementById(`harga${rowCount}`).value = "";
                return;
            }

            axios.get(`/produk/produk_name/${produkId}`)
                .then(response => {
                    const produk = response.data.produk;

                    document.getElementById(`harga${rowCount}`).value = produk ? produk.harga_jual : "";
                })
                .catch(error => {
                    console.error("Gagal memuat data produk:", error);
                    document.getElementById(`harga${rowCount}`).value = "";
                });
        };
    </script>

    <script>
        function updateStatusPembelian() {
            const konsumenSelect = document.getElementById('id_konsumen');
            const totalBayarInput = document.getElementById('total_bayar');
            const totalJualInput = document.getElementById('total_jual');
            const piutangKembali = document.getElementById('piutangKembali');

            if (!konsumenSelect || !totalBayarInput || !totalJualInput || !piutangKembali ) {
                console.error("Element tidak ditemukan");
                return;
            }

            const selectedOption = konsumenSelect.options[konsumenSelect.selectedIndex];
            const satatusKonsumen = selectedOption ? selectedOption.getAttribute('data-status') : null;

            if (satatusKonsumen === 'MAHASISWA') {
                //jika konsumen adalah mahasiswa
                totalBayarInput.value = totalJualInput.value;
                totalBayarInput.readOnly = true;
                piutangKembali.value = 0;
                piutangKembali.readOnly = true;
            } else {
                totalBayarInput.value = '';
                totalBayarInput.readOnly = false;
                piutangKembali.readOnly = true;
            }
            // var e = document.getElementById("id_konsumen");
            // var value = e.value;
            // var text = e.options[e.selectedIndex];
            // var dataStatus = text.getAttribute("data-status");

            // // console.log(dataStatus);
            // const select = document.getElementById('status_pembelian');

            // if (dataStatus === "MAHASISWA") {
            //     document.getElementById('total_bayar').disabled = true;
            // } else {
            //     document.getElementById('total_bayar').disabled = false;
            // }
        }
    </script>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH D:\Kuliah\GITHUB\Project-Laravel\tugas kasir\Kasir-LP3I\resources\views/page/penjualan/create.blade.php ENDPATH**/ ?>