<?php

namespace App\Http\Controllers;

use App\Models\DetailPembelian;
use App\Models\Pembelian;
use App\Models\Produk;
use App\Models\Supplier;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class PembelianController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $data = Pembelian::paginate(5);
        return view('page.pembelian.index')->with([
            'data' => $data,
        ]);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        $Supplier = Supplier::all();
        $produk = Produk::where('status','BELUM')->get();
        $kodePembelian = Pembelian::createCode();
        return view('page.pembelian.create', compact('kodePembelian'))->with([
            'supplier' => $Supplier,
            'produk' => $produk,
        ]);
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $kode_pembelian = $request->input('kode_pembelian');

        $produk = $request->input('produk', []);
        foreach ($produk as $index => $p) {

            // Cari produk di tabel produk_jual
            $produk = Produk::where('kode_produk', $p)->first();
            if ($produk) {
                // Kurangi qty di produk_jual
                $produk->qty += $request->qty[$index];
                $produk->save();
            } else {
                return redirect()
                    ->back()
                    ->with('error', "Produk $p tidak ditemukan.");
            }
            // ===============================//

            $dataDetail = [
                'kode_pembelian' => $kode_pembelian,
                'kode_produk' => $p,
                'qty' => $request->qty[$index],
                'total' => $request->total_harga[$index],
            ];
            DetailPembelian::create($dataDetail);
        }

        $data = [
            'kode_pembelian' => $kode_pembelian,
            'tgl_pembelian' => $request->input('tgl_pembelian'),
            'id_supplier' => $request->input('id_supplier'),
            'total_bayar'=> $request->input('total_bayar'),
        ];

        Pembelian::create($data);

        return redirect()
            ->route('pembelian.index')
            ->with('message', 'Data sudah ditambahkan');
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        $kodePembelian = $request->input('kode_pembelian');

        $data = [
            'tgl_pembelian' => $request->input('tgl_pembelian'),
            'id_supplier' => $request->input('id_supplier'),
            'total_bayar' => $request->input('total_bayar'),
        ];

        $dataDetail = [
            'kode_produk' => $request->input('kode_produk'),
            'qty' => $request->input('qty'),
            'total' => $request->input('total'),
        ];

        $datas = Pembelian::where('kode_pembelian', $kodePembelian)->first();
        $datas->update($data);

        $datasDetail = DetailPembelian::where('kode_pembelian', $kodePembelian)->first();
        $datasDetail->update($dataDetail);

        return response()->json([
            'message_update' => "Data Updated!"]);

    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        try {
            $data = Pembelian::findOrFail($id);
            $kodePembelian = $data->kode_pembelian;

            $data = Pembelian::where('kode_pembelian', $kodePembelian)->first();
            $dataDetail = DetailPembelian::where('kode_pembelian', $kodePembelian)->first();

            if ($data) {
                $data->delete();
            }

            if ($dataDetail) {
                $dataDetail->delete();
            }

            return response()->json([
                'message_delete' => "Data Deleted!"
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'error' => 'Failed to delete data.',
                'message' => $e->getMessage()
            ], 500);
        }
    }
}